import SwiftUI

struct MedicationsView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Medications & Alerts")
                .font(.largeTitle)
                .fontWeight(.bold)
            Text("Donepezil - Take daily before sleeping")
            Text("Rivastigmine - Take in the morning after food")
            Text("Galantamine - ❗ Prescription refill needed")
            
            Spacer()
        }
        .padding()
        .navigationTitle("Medications")
    }
}


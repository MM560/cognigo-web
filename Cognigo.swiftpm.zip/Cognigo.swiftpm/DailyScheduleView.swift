import SwiftUI

struct DailyScheduleView: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 10) {
                Text("Daily Schedule")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                
                Text("""
                - Wash, brush teeth, get dressed 08:00
                - Prepare and eat breakfast 08:15
                - Have coffee, make conversation 09:00
                - Discuss the newspaper, try a craft project 09:30
                - Take a break, have some quiet time 10:00
                - Do some chores together 11:00
                - Take a walk, play an active game 11:30
                - Prepare and eat lunch, read mail, wash dishes 12:00
                - Listen to music, do crossword puzzles, watch TV 13:30
                - Do some gardening, take a walk, visit a friend 14:30
                - Take a short break or nap 15:30
                - Prepare and eat dinner, clean up the kitchen 17:00
                - Coffee and dessert 18:30
                - Play cards, watch a movie, give a massage 19:15
                - Take a bath, get ready for bed, read a book 20:30
                """)
                
                Spacer()
            }
            .padding()
        }
        .navigationTitle("Daily Schedule")
    }
}


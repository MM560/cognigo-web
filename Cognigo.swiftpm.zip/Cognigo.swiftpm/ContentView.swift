import SwiftUI

struct ContentView: View {
    var body: some View {
        HomePageView() // This will show your homepage when the app starts
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


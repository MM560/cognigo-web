import SwiftUI

struct UpgradeView: View {
    var body: some View {
        VStack {
            Text("Upgrade to Pro for $14.99")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding()
            
            Spacer()
        }
        .navigationTitle("Upgrade")
    }
}


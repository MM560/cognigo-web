import SwiftUI

struct MedicalRecordsView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Patient Information")
                .font(.title2)
                .fontWeight(.bold)
            Text("First name: User")
            Text("Last name: Example")
            Text("Date of birth: 01/01/1960")
            Text("Gender: Male")
            Text("Patient identifier: ABC123")
            
            Divider()
            
            Text("Medical Records Summary")
                .font(.title2)
                .fontWeight(.bold)
            Text("Completed by: Doctor")
            Text("Date: 02/27/25")
            Text("02/12/25 Appointment update:")
            Text("User saw Dr. Doctor for consultation regarding a new prescription of Donepezil due to new symptoms")
            
            Spacer()
        }
        .padding()
        .navigationTitle("Medical Records")
    }
}


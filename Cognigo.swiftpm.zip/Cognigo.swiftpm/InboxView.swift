import SwiftUI

struct InboxView: View {
    var body: some View {
        VStack {
            Text("Inbox")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding()
            List {
                Text("Account setup complete")
            }
            Spacer()
        }
        .navigationTitle("Inbox")
    }
}

struct InboxView_Previews: PreviewProvider {
    static var previews: some View {
        InboxView()
    }
}


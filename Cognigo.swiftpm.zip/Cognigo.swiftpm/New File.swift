import SwiftUI

struct HomePageView: View {
    @StateObject private var aiScheduler = ScheduleAIManager()
    @StateObject private var healthAI = HealthMonitorAI()
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    
                    // Header
                    HStack {
                        Text("Cognigo")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                        Spacer()
                        Image(systemName: "brain.head.profile")
                            .resizable()
                            .frame(width: 30, height: 30)
                            .foregroundColor(.cyan)
                    }
                    .padding()
                    .frame(height: 60)
                    .background(Color.black)
                    
                    // AI Health Alert
                    VStack(alignment: .leading, spacing: 10) {
                        Text("AI Health Monitor")
                            .font(.headline)
                        Text(healthAI.checkVitals())
                            .foregroundColor(.red)
                    }
                    .padding()
                    .background(Color.yellow.opacity(0.2))
                    .cornerRadius(10)
                    
                    // AI Schedule Display
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Today's Smart Schedule")
                            .font(.headline)
                        ForEach(aiScheduler.schedule, id: \.self) { item in
                            Text("• \(item)")
                        }
                    }
                    .padding()
                    .background(Color.cyan.opacity(0.2))
                    .cornerRadius(10)
                    
                    // Simulate AI Update
                    Button("Simulate AI Data") {
                        healthAI.simulateDataUpdate()
                        aiScheduler.generateSchedule(basedOn: healthAI.vitals)
                    }
                    .padding()
                    .background(Color.black)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    
                    // Inbox Section
                    NavigationLink(destination: InboxView()) {
                        VStack(alignment: .leading, spacing: 10) {
                            Text("Hello User, your medication must be taken in **45 minutes**, followed by your meal")
                                .font(.body)
                            HStack {
                                Spacer()
                                Image(systemName: "envelope")
                                Text("Inbox")
                            }
                            .foregroundColor(.blue)
                        }
                        .padding()
                        .background(Color(UIColor.systemGray6))
                        .cornerRadius(10)
                    }
                    .padding(.horizontal)
                    
                    // Feature Buttons
                    VStack(spacing: 20) {
                        NavigationLink(destination: MedicalRecordsView()) {
                            HomePageButton(title: "Medical Records/Vitals", icon: "chart.bar.fill")
                        }
                        NavigationLink(destination: MedicationsView()) {
                            HomePageButton(title: "Medications & Alerts", icon: "brain.head.profile")
                        }
                        NavigationLink(destination: DailyScheduleView()) {
                            HomePageButton(title: "Daily Schedule", icon: "calendar")
                        }
                    }
                    .padding(.horizontal)
                    
                    // Upgrade Section
                    NavigationLink(destination: UpgradeView()) {
                        Text("↑ Upgrade your Plan ↑")
                            .fontWeight(.bold)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.black)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }
                    .padding(.horizontal)
                    
                    Spacer()
                    
                    // Bottom Nav Bar
                    HStack {
                        Button(action: {
                            print("Home tapped")
                        }) {
                            VStack {
                                Image(systemName: "house.fill")
                                Text("Home")
                            }
                        }
                        .foregroundColor(.black)
                        
                        Spacer()
                        
                        Button(action: {
                            print("My Account tapped")
                        }) {
                            VStack {
                                Image(systemName: "person.circle")
                                Text("My Account")
                            }
                        }
                        .foregroundColor(.black)
                    }
                    .padding()
                    .background(Color(UIColor.systemGray6))
                }
                .padding()
            }
        }
        .onAppear {
            aiScheduler.generateSchedule(basedOn: healthAI.vitals)
        }
    }
}

// Reusable Button Component
struct HomePageButton: View {
    var title: String
    var icon: String
    
    var body: some View {
        HStack {
            Image(systemName: icon)
                .resizable()
                .frame(width: 30, height: 30)
                .padding()
            Text(title)
                .font(.headline)
            Spacer()
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(Color(UIColor.systemGray6))
        .cornerRadius(10)
    }
}

struct HomePageView_Previews: PreviewProvider {
    static var previews: some View {
        HomePageView()
    }
}

